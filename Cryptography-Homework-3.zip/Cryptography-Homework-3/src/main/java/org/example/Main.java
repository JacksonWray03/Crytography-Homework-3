package org.example;
import javax.crypto.*;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.io.*;
import java.security.*;
import java.security.spec.*;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Scanner;

public class Main {


    public static void main(String[] args) throws Exception {

        Scanner scanner = new Scanner(System.in);

        System.out.println();
        System.out.println("Please input Plaintext");
        String message = scanner.nextLine();

        // Part 1: AES Encryption and Decryption

        KeyGenerator keyGen = KeyGenerator.getInstance("AES");

        keyGen.init(128);
        SecretKey sharedAESKey = keyGen.generateKey();

        System.out.println();

        System.out.println("Plaintext entered: " + message);

        aesEncrypt(sharedAESKey, message, "data/ctext.txt","not test");


        System.out.println();
        System.out.println("Plaintext after Decryption:");
        aesDecrypt(sharedAESKey, "data/ctext.txt", "not test");




        // Part 2


        // Generate keys
        KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance("RSA");
        keyPairGenerator.initialize(2048);
        KeyPair keys = keyPairGenerator.generateKeyPair();


        System.out.println();
        System.out.println("RSA Encryption");

        System.out.println();
        System.out.println("Please input Plaintext");

        String message2 = scanner.nextLine();

        System.out.println("Plaintext entered: " + message2);

        rsaEncrypt(message2, keys.getPublic(), "data/ctext2.txt", "not test");
        rsaDecrypt(keys.getPrivate(),"data/ctext2.txt", "not test");



        // Part 3


        tester("both");




    }


    public static void aesEncrypt(SecretKey key, String plainText, String filePath, String mode) throws NoSuchPaddingException, NoSuchAlgorithmException, InvalidAlgorithmParameterException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException, IOException {
        // Set Cipher Mode to CBC with padding
        Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");

        // Generate IV and write it
        IvParameterSpec iv = new IvParameterSpec(new byte[16]);
        SecureRandom random = new SecureRandom();
        random.nextBytes(iv.getIV());

        FileOutputStream ivFile = new FileOutputStream("data/iv.txt");
        ivFile.write(iv.getIV());


        // Set parameters for cipher and store it
        cipher.init(Cipher.ENCRYPT_MODE, key, iv);
        byte[] ciphertext = cipher.doFinal(plainText.getBytes());


        FileOutputStream cipherFile = new FileOutputStream(filePath);
        cipherFile.write(ciphertext);

        if(!mode.equals("test"))
        {
            System.out.println("Ciphertext from input: " + Base64.getEncoder().encodeToString(ciphertext));

        }
    }


    public static void aesDecrypt(SecretKey key, String filePath, String mode) throws NoSuchPaddingException, NoSuchAlgorithmException, IOException, InvalidAlgorithmParameterException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException {

        // Set cipher mode to CBC with padding
        Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");

        // Read IV
        byte[] ivBytes = new byte[16];
        FileInputStream ivFile = new FileInputStream("data/iv.txt");
        ivFile.read(ivBytes);

        IvParameterSpec iv = new IvParameterSpec(ivBytes);


        // Read ciphertext
        byte[] ciphertext;
        FileInputStream cipherFile = new FileInputStream(filePath);
        ciphertext = cipherFile.readAllBytes();

        // Decrypt cyphertext
        cipher.init(Cipher.DECRYPT_MODE, key, iv);
        byte[] plaintext = cipher.doFinal(ciphertext);

        if(!mode.equals("test"))
        {
            System.out.println("Decrypted message: " + new String(plaintext).trim());

        }


    }

    public static void rsaEncrypt(String plainText, PublicKey publicKey, String filePath, String mode) throws Exception {

        // Set the cipher to RSA with padding
        Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");

        // Set the cipher to use the passed publicKey
        cipher.init(Cipher.ENCRYPT_MODE, publicKey);

        // Write the cyphertext to the file
        byte[] ciphertext = cipher.doFinal(plainText.getBytes());
        FileOutputStream cipherFile = new FileOutputStream(filePath);
        cipherFile.write(ciphertext);


        if(!mode.equals("test"))
        {
            System.out.println("Ciphertext from input: " + Base64.getEncoder().encodeToString(ciphertext));

        }




    }

    public static void rsaDecrypt(PrivateKey privateKey, String filePath, String mode) throws Exception {
        // Set Cypher to RSA with padding and use the passed private key
        Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
        cipher.init(Cipher.DECRYPT_MODE, privateKey);

        // Read ciphertext from file
        byte[] ciphertext;
        FileInputStream cipherFile = new FileInputStream(filePath);
        ciphertext = cipherFile.readAllBytes();

        // Decrypt CipherText
        byte[] plaintext = cipher.doFinal(ciphertext);


        if(!mode.equals("test"))
        {
            System.out.println("Decrypted message: " + new String(plaintext).trim());


        }


    }

    public static void tester(String mode) throws Exception {
        ArrayList<Integer> keySizes = new ArrayList<>();
        keySizes.add(128);
        keySizes.add(192);
        keySizes.add(256);
        String testMessage = "test";

        ArrayList<Integer> keySizesRSA = new ArrayList<>();
        keySizesRSA.add(1024);
        keySizesRSA.add(2048);
        keySizesRSA.add(4096);


        if (mode.equals("both") || mode.equals("AES"))
        {
            KeyGenerator keyGenTester = KeyGenerator.getInstance("AES");
            for (int i =0;i<3;i++)
            {
                long startTime = System.nanoTime();
                keyGenTester.init(keySizes.get(i));
                SecretKey sharedAESKeyTester = keyGenTester.generateKey();
                for (int j=0; j<100;j++)
                {
                    aesEncrypt(sharedAESKeyTester, testMessage, "data/ctextTester.txt","test");
                    aesDecrypt(sharedAESKeyTester,"data/ctextTester.txt","test");
                }
                long averageTime = ((System.nanoTime() - startTime) / 100);
                System.out.println("Average time for encryption + decryption for AES "+ keySizes.get(i)+ " bit key: " + averageTime + " nanoseconds or " + (double)averageTime/1000000000+ " seconds");

            }

            if (mode.equals("both") || mode.equals("RSA"))
            {
                KeyPairGenerator keyPairGeneratorTester = KeyPairGenerator.getInstance("RSA");

                for (int i =0;i<3;i++)
                {
                    long startTimeRSA = System.nanoTime();
                    keyPairGeneratorTester.initialize(keySizesRSA.get(i));

                    KeyPair keysTester = keyPairGeneratorTester.generateKeyPair();

                    for (int j=0; j<100;j++)
                    {
                        rsaEncrypt(testMessage,keysTester.getPublic(),"data/ctextTester.txt","test");
                        rsaDecrypt(keysTester.getPrivate(), "data/ctextTester.txt","test");
                    }
                    long averageTimeRSA = ((System.nanoTime() - startTimeRSA) / 100);
                    System.out.println("Average time for encryption + decryption for RSA "+ keySizesRSA.get(i)+ " bit key: " + averageTimeRSA + " nanoseconds or " + (double)averageTimeRSA/1000000000+ " seconds");

                }
            }
        }

    }
}